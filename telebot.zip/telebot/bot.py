from telethon import TelegramClient, sync, events, errors
from telethon.errors import SessionPasswordNeededError
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from time import sleep
import sys,os


banner = """\033[0;35m       __       _       __
      / /__    (_)___ _/ /______ _
 __  / / _ \  / / __ `/ //_/ __ `/
/ /_/ /  __/ / / /_/ / ,< / /_/ /
\____/\___/_/ /\__,_/_/|_|\__,_/
         /___/
\033[0;34m=========================================================
\033[1;32mAuthor By  \033[1;31m:\033[1;0m Kadal15
\033[1;32mChannel Yt\033[1;31m : \033[1;0mJejaka Tutorial"""

print (banner)

if len(sys.argv)<2:
   print ("\033[1;32m\n\n\nUsage : python Achat.py +62")
   sys.exit()
# Use your own values from my.telegram.org
api_id = 717425
api_hash = '322526d2c3350b1d3530de327cf08c07'
phone_number = sys.argv[1]
# The first parameter is the .session file name (absolute paths allowed)
client = TelegramClient(phone_number, api_id, api_hash)

client.connect()
if not client.is_user_authorized():
  try:
    client.send_code_request(phone_number)
    me = client.sign_in(phone_number, input('\033[1;0m\n\n\nEnter code : '))
  except SessionPasswordNeededError:
    passw = input("\033[1;0mYour 2fa Password : ")
    me = client.start(phone_number,passw)

myself = client.get_me()
os.system("clear")
print (banner)
print ("\033[1;32mWelcome",myself.first_name,"\nBot Auto Chat Doge Tip Bot\n\n\n")

channel_username='@dogetipbotgroup'
channel_entity=client.get_entity(channel_username)
chat = open("chatbox.txt","r")
while True:
   for chat1 in chat:
     client.send_message(entity=channel_entity,message=chat1)
     posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
     mid = posts.messages[1].message
     print ("\033[1;33mChat Group\033[1;31m >\033[1;32m ",mid)
     sleep(100)
