import requests, sys, os, re
from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from bs4 import BeautifulSoup
from time import sleep

def cekbal():                                                         client.send_message(entity=channel_entity,message="/balance")
   posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
   messageId = posts.messages[0].message
   if messageId == "/balance":                                           sleep(2)                                                           posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
      messageId = posts.messages[0].message
      print (messageId)
   else:
      print (messageId)


def visit():
   client.send_message(entity=channel_entity,message="/visit")
   sleep(1)
   posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
   messageId = posts.messages[0].reply_markup.rows[0].buttons[0].url
   aa = posts.messages[0].message
   mid = posts.messages[0].id
   r = c.get(messageId, headers=ua)
   soup = BeautifulSoup(r.content, "html.parser")
   if soup.find("div",class_="g-recaptcha") is None:
      sleep(2)
      posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
      a = posts.messages[0].message
      sec = re.findall( r'([\d.]*\d+)', a)
      sleep(int(sec[0]))
      sleep(1)
      posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
      b = posts.messages[1].message
      if b == aa:
        sys.stdout.write("\r")
        sys.stdout.write("Captcha Detected")
        sys.stdout.flush()
        client(GetBotCallbackAnswerRequest(
        channel_username,
        mid,
        data=posts.messages[0].reply_markup.rows[0].buttons[1].data
        ))
        sys.stdout.write("\r")
        sys.stdout.write("Skip Captcha       ")
        sys.stdout.flush()
      else:
        print (b)
        cekbal()
   else:                                                                 sys.stdout.write("\r")
      sys.stdout.write("Captcha Detected")
      sys.stdout.flush()
      client(GetBotCallbackAnswerRequest(
      channel_username,                                                  mid,
      data=posts.messages[0].reply_markup.rows[0].buttons[1].data
      ))
      sys.stdout.write("\r")
      sys.stdout.write("Skip Captcha       ")                            sys.stdout.flush()                                           
api_id = "210400"
api_hash = '58839ada91de89607ec39b86c3f85247'
phone_number = "+6285336117892"

client = TelegramClient("Session/"+phone_number, api_id, api_hash)

client.connect()
f not client.is_user_authorized():
    client.send_code_request(phone_number)                             me = client.sign_in(phone_number, input('Enter code: '))
                                                                   myself = client.get_me()
print ("Welcome",myself.first_name,"\n\n")


channel_username='@Dogecoin_click_bot'
channel_entity=client.get_entity(channel_username)

c = requests.Session()
ua = {
   "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; A1603 Build/LMY47I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.121 Mobile Safari/537.36"
}

while True:
  visit()
