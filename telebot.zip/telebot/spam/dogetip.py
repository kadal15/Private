import requests, sys, os, re
from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from bs4 import BeautifulSoup
from time import sleep

api_id = '210400'
api_hash = '58839ada91de89607ec39b86c3f85247'
phone_number = "+6285336117892"

client = TelegramClient(phone_number, api_id, api_hash)

client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone_number)
    me = client.sign_in(phone_number, input('Enter code : '))

myself = client.get_me()
print ("Welcome",myself.first_name,"\n\n")

channel_username='@dogetipbotgroup'
channel_entity=client.get_entity(channel_username)

while True:
   chat = ["Hi All","Nice Doge","Rain Please","whats app bro","i love doge", "Rain Doge Please","whats ups people on the world","hello guys","nice to meet you","Hi"]
   for chat1 in chat:
     client.send_message(entity=channel_entity,message=chat1)
     posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
     mid = posts.messages[1].message
     print ("Chat Group > ",mid)
     sleep(30)
