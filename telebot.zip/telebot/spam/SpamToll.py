from telethon import TelegramClient, sync
from telethon.errors import PhoneCodeInvalidError, PhoneNumberBannedError
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest
import re, time, sys


banner = """\033[0;32m
=============================================================\033[0;31m
#######                       #####
   #    ###### #      ###### #     # #####    ##   #    #
   #    #      #      #      #       #    #  #  #  ##  ##
   #    #####  #      #####   #####  #    # #    # # ## #
   #    #      #      #            # #####  ###### #    #
   #    #      #      #      #     # #      #    # #    #
   #    ###### ###### ######  #####  #      #    # #    #
\033[0;32m=============================================================
\033[1;32mAuthor By \033[1;31m : \033[1;0mKadal15           \033[1;30m| \033[1;32m        Tools Spam Telegram
\033[1;32mChannel Yt \033[1;31m: \033[1;0mJejaka Tutorial   \033[1;30m|\033[0;31m Take Your Own Risk

"""

menugroup = """[1] Public Group
[2] Private Group"""


pilihan = """\033[1;0m[1]\033[1;32m Spam Orang
\033[1;0m[2]\033[1;32m Spam Group"""

def person():
   print ("\n\033[1;36mMasukkan Username Korban\n\033[1;32mContoh \033[1;31m: \033[1;0m@Ntshack1")
   nama = input("\033[1;32mUsername\033[1;31m :\033[1;0m ")
   x =  input("\033[1;32mJumlah\033[1;31m :\033[1;0m ")
   text = input("\033[1;32mText\033[1;31m :\033[1;0m ")
   slp = input("\033[1;32mSleep \033[1;31m:\033[1;0m ")
   print ("\n\n\033[1;33mStart To Send Spam Text....!")
   for i in range(int(x)):
      try:
         print ("\033[1;32mSending Message \033[1;31m:\033[1;31m", text)
         client.send_message(nama, text)
         time.sleep(int(slp))
      except:
         print ("\033[1;31mfiled To Send Message")

   print ("\033[1;32mSpamming Complite.....!")

def group():
    while True:
       print (menugroup)
       pil2 = input("\nSpam Tool >> ")
       if pil2 == "01" or pil2 == "1":
          print ("\n\033[1;36mMasukkan Link Ivite Group Korban")
          link = input("\033[1;32mGroup \033[1;31m:\033[1;0m ")
          x =  input("\033[1;32mJumlah\033[1;31m :\033[1;0m ")
          text = input("\033[1;32mText\033[1;31m :\033[1;0m ")
          slp = input("\033[1;32mSleep \033[1;31m:\033[1;0m ")
          print ("\n\n\033[1;36mStart To Send Spam Text....!")
          for i in range(int(x)):
            try:
              entity=client.get_entity(link)
              client.send_message(entity=entity,message=text)
              print ("\033[1;32mSending Message\033[1;31m :\033[1;31m", text)
              time.sleep(int(slp))
            except:
              print ("Anda Belum Bergabung Di Group\nTry To Join Group")
              res=client.get_entity(link)
              ab = res.username
              client(JoinChannelRequest(ab))
          break
       elif pil2 == "02" or pil2 == "2":
          print ("\n\033[1;36mMasukkan Link Ivite Group Korban")
          link = input("\033[1;32mGroup \033[1;31m:\033[1;0m ")
          x =  input("\033[1;32mJumlah\033[1;31m :\033[1;0m ")
          text = input("\033[1;32mText\033[1;31m :\033[1;0m ")
          slp = input("\033[1;32mSleep \033[1;31m:\033[1;0m ")
          print ("\n\n\033[1;36mStart To Send Spam Text....!")
          for i in range(int(x)):
            try:
               entity=client.get_entity(link)
               client.send_message(entity=entity,message=text)
               print ("\033[1;32mSending Message\033[1;31m :\033[1;31m", text)
               time.sleep(int(slp))
            except:
               print ("Anda Belum Bergabung Di Group Sialahkan Masukkan Access Hash Group\nMisal : https://t.me/joinchat/HxAoGwsJ9oeB8Qynt0UUxw\nAccess Hash = HxAoGwsJ9oeB8Qynt0UUxw")
               access = input("Spam Tool >> ")
               client(ImportChatInviteRequest(access))
          print ("\033[1;32mSpamming Complite")
          break

def menu():
   while True:
      print (pilihan)
      pil = input("\n\033[1;0mSpamToo \033[0;31m>>\033[1;0m ")
      if pil == "1" or pil == "01":
        person()
        break
      elif pil == "2" or pil == "02":
        group()
        break
      else:
        print ("\033[1;31mERROr : Wrong Input.....!")




if len(sys.argv)<2:
   print ("\033[1;32mUsage : python SpamTool.py +62")

else:
   api_id = "210400"
   api_hash = '58839ada91de89607ec39b86c3f85247'
   phone_number = sys.argv[1]
   client = TelegramClient("Session/"+phone_number, api_id, api_hash)
   client.connect()
   if not client.is_user_authorized():
       try:
          client.send_code_request(phone_number)
          while True:
             try:
                me = client.sign_in(phone_number, input('Enter code: '))
                break
             except PhoneCodeInvalidError:
                print ("Your Code Is Invalid")
       except PhoneNumberBannedError:
          print("Phone number is banned.")
          this_client.disconnect()

   myself = client.get_me()
   print (banner)
   print ("\033[1;33mWelcome To TeleSpam",myself.first_name)
   menu()


