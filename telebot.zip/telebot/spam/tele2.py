from telethon import TelegramClient, sync

import re, time
api_id = "210400"
api_hash = '58839ada91de89607ec39b86c3f85247'
phone_number = "+6285336117892"

client = TelegramClient("Session/"+phone_number, api_id, api_hash)

client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone_number)
    me = client.sign_in(phone_number, input('Enter code: '))

myself = client.get_me()
print ("\nWelcome",myself.first_name,"\n\n")

