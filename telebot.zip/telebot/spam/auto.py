from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from time import sleep


api_id = "210400"
api_hash = '58839ada91de89607ec39b86c3f85247'
phone_number = "+6285348006188"

client = TelegramClient("Session/"+phone_number, api_id, api_hash)

client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone_number)
    me = client.sign_in(phone_number, input('Enter code : '))

myself = client.get_me()
print ("Welcome",myself.first_name,"\n\n")


@client.on(events.NewMessage(pattern='(?i).*Hello'))
async def handler(event):
    sleep(20)
    await event.reply('Nyoba Bot Njir')
    print (event.message.message)

@client.on(events.NewMessage(pattern='(?i).*j'))
async def handler(event):
    sleep(1)
    await event.reply('Nyoba Bot Njir')
    print (event.message.message)

@client.on(events.NewMessage(pattern='(?i).*apa kabar'))
async def handler(event):
    sleep(1)
    await event.reply('Nyoba Bot Njir')
    print (event.message.message)

@client.on(events.NewMessage(pattern='(?i).*hi'))
async def handler(event):
    sleep(1)
    await event.reply('Nyoba Bot Njir')
    print (event.message.message)


client.run_until_disconnected()
