from urllib.parse import urlparse



t = "https://t.me/joinchat/HxAoGxHQdFVQsAthy9K-KQ"


a = urlparse(t)
print (str(a.path('joinchat/')))

