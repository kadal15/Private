from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from time import sleep

# Use your own values from my.telegram.org
api_id = 717425
api_hash = '322526d2c3350b1d3530de327cf08c07'
phone_number = "+6285336117892"
# The first parameter is the .session file name (absolute paths allowed)
client = TelegramClient("session/"+phone_number, api_id, api_hash)

client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone_number)
    me = client.sign_in(phone_number, input('Enter code : '))

myself = client.get_me()
print ("Welcome",myself.first_name,"\n\n")

channel_username='@queennyomi143'
channel_entity=client.get_entity(channel_username)
while True:
   chat = ["Hi All","Nice Doge","whats app bro","i love doge","whats ups people on the world","nice to meet you", "woot","Doge","heya","doge doge doge","Good poeple","Come On Men","Hello World","hahahahaha have nice day dude","i trust doge","i belive you all good people","Stay Here And Wait Good News","have a nice day","hai all","Lol here’s a cup ☕️","This Group Its so cool","doge i love","wahoo","yuuuhuuuu","smart people","good days ever","good doge","go go go","Amazing","Wkwkwkw Many People in here","Nice","Thanks","Yahoouy","Go Doge Go","Ok","Yeah....!!!!","Wow"]
   for chat1 in chat:
     client.send_message(entity=channel_entity,message=chat1)
     posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
     mid = posts.messages[1].message
     print ("Chat Group > ",mid)
     sleep(100)
