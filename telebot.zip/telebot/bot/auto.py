from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from time import sleep
import random

# Use your own values from my.telegram.org
api_id = 717425
api_hash = '322526d2c3350b1d3530de327cf08c07'
phone_number = "+6283865857106"
# The first parameter is the .session file name (absolute paths allowed)
client = TelegramClient(phone_number, api_id, api_hash)

client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone_number)
    me = client.sign_in(phone_number, input('Enter code : '))

myself = client.get_me()
print ("Welcome",myself.first_name,"\n\n")

text = ["Hello Dude Hahaha","Hey bro and sis","Hii","hahahahahaha Hello bro"]
mes = random.choice(text)
i = 0

while True:
  @client.on(events.NewMessage)
  async def my_event_handler(event):
    print (i)
    if 'hello' in event.raw_text:
      i += 1
      print (i)
      if i == 10:
        i = 0
        print (event.raw_text)
        sleep(7)
        await event.reply(mes)
        sleep(60)
    else:
      print (event.raw_text)

  client.start()
