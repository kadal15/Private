u="y"
while [ $u = "y" ]
do
 python t.py
done
