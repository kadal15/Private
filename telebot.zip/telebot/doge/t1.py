from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from telethon.errors import SessionPasswordNeededError
from time import sleep
import json,re,sys,os
try:
   import requests
   from bs4 import BeautifulSoup
except:
   print ("Hmmm Sepertinya Modul Requests Dan Bs4 Belum Terinstall\nTo install Please Type pip install requests and pip install bs4")


banner = """\033[0;35m       __       _       __
      / /__    (_)___ _/ /______ _
 __  / / _ \  / / __ `/ //_/ __ `/
/ /_/ /  __/ / / /_/ / ,< / /_/ /
\____/\___/_/ /\__,_/_/|_|\__,_/
         /___/
\033[0;34m=========================================================
\033[1;32mAuthor By  \033[1;31m:\033[1;0m Kadal15
\033[1;32mChannel Yt\033[1;31m : \033[1;0mJejaka Tutorial"""

if not os.path.exists("session"):
    os.makedirs("session")

print (banner)
if len(sys.argv)<2:
   print ("\n\n\n\033[1;32mUsage : python main.py +62")
   sys.exit(1)

def tunggu(x):
    sys.stdout.write("\r")
    sys.stdout.write("                                                               ")
    for remaining in range(x, 0, -1):
       sys.stdout.write("\r")
       sys.stdout.write("\033[1;30m#\033[1;0m{:2d} \033[1;32mseconds remaining".format(remaining))
       sys.stdout.flush()
       sleep(1)


c = requests.Session()
ua = {
   "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; A1603 Build/LMY47I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.121 Mobile Safari/537.36"
}



api_id = 717425
api_hash = '322526d2c3350b1d3530de327cf08c07'
phone_number = sys.argv[1]

client = TelegramClient("session/"+phone_number, api_id, api_hash)
client.connect()
if not client.is_user_authorized():
  try:
    client.send_code_request(phone_number)
    me = client.sign_in(phone_number, input('\n\n\n\033[1;0mEnter Yout Code Code : '))
  except SessionPasswordNeededError:
   passw = input("\033[1;0mYour 2fa Password : ")
   me = client.start(phone_number,passw)
myself = client.get_me()
os.system("clear")
print (banner)
print ("\033[1;32mWelcome To TeleBot",myself.first_name,"\n\033[1;32mBot Ini Di Gunakan Untuk Menuyul DogeClickBot Bersaudara\n\n")

teks = """Sorry, there are no new ads available. 😟

You have not enabled alerts for new click tasks."""

def visiturl(x):
  sys.stdout.write("\r")
  sys.stdout.write("                                                              ")
  sys.stdout.write("\r")
  sys.stdout.write("\033[1;30m# \033[1;33mMencoba Mengambil URL")
  sys.stdout.flush()
  channel_username=x
  channel_entity=client.get_entity(channel_username)
  client.send_message(entity=channel_entity,message="/visit")
  sleep(2)
  posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
  if posts.messages[0].message == teks:
     print ("\033[1;30m# \033[1;31mIklan Sudah Habis Coba Lagi Besok\n")
     sys.exit()
  else:
    try:
     url = posts.messages[0].reply_markup.rows[0].buttons[0].url
     sys.stdout.write("\r")
     sys.stdout.write("\033[1;30m# \033[1;33mVisit "+url)
     sys.stdout.flush()
     id = posts.messages[0].id
     r = c.get(url, headers=ua)
     soup = BeautifulSoup(r.content,"html.parser")
     if soup.find("div",class_="g-recaptcha") is None and soup.find('div', id="headbar") is None:
        sleep(5)
        posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
        message = posts.messages[0].message
        sec = re.findall( r'([\d.]*\d+)', message)
        tunggu(int(sec[0]))
        sleep(3)
        posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
        messageres = posts.messages[1].message
        sys.stdout.write("\r\033[1;30m# \033[1;32m"+messageres+"\n")


     elif soup.find('div', id="headbar") is not None:
        for dat in soup.find_all('div',class_="container-fluid"):
            code = dat.get('data-code')
            timer = dat.get('data-timer')
            tokena = dat.get('data-token')
            tunggu(int(timer))
            r = c.post("https://dogeclick.com/reward",data={"code":code,"token":tokena},headers=ua, allow_redirects=False)
            js = json.loads(r.text)
            if channel_username == "@Litecoin_click_bot":
               sys.stdout.write("\r\033[1;30m# \033[1;32mYou earned "+js['reward']+" LTC for visiting a site!\n")
            elif channel_username == "@Dogecoin_click_bot":
               sys.stdout.write("\033[1;30m# \033[1;32mYou earned "+js['reward']+" Doge for visiting a site!\n")
            elif channel_username == "@BCH_clickbot":
               sys.stdout.write("\r\033[1;30m# \033[1;0mYou earned "+js['reward']+" BCH for visiting a site!\n")
            elif channel_username == "@Zcash_click_bot":
               sys.stdout.write("\r\033[1;30m# \033[1;32mYou earned "+js['reward']+" ZEC for visiting a site!\n")
            elif channel_username == "@BitcoinClick_bot":
               sys.stdout.write("\r\033[1;30m# \033[1;32mYou earned "+js['reward']+" Satoshi for visiting a site!\n")
     else:
        sys.stdout.write("\r")
        sys.stdout.write("                                                                ")
        sys.stdout.write("\r")
        sys.stdout.write("\033[1;30m# \033[1;31mCaptcha Detected")
        sys.stdout.flush()
        client(GetBotCallbackAnswerRequest(
        channel_username,
        id,
        data=posts.messages[0].reply_markup.rows[0].buttons[1].data
        ))
        sys.stdout.write("\r\033[1;30m# \033[1;31mSkip Captcha...!       \n")
    except:
       pass

print ("\033[1;37mMemulai Menuyul......!")
while True:
   visiturl("@Litecoin_click_bot")
   visiturl("@Dogecoin_click_bot")
   visiturl("@BCH_clickbot")
   visiturl("@Zcash_click_bot")
   visiturl("@BitcoinClick_bot")
