import requests, sys, os, re
from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from bs4 import BeautifulSoup
from time import sleep

c = requests.Session()
ua = {
   "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; A1603 Build/LMY47I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.121 Mobile Safari/537.36"
}
# Use your own values from my.telegram.org
api_id = 717425
api_hash = '322526d2c3350b1d3530de327cf08c07'
phone_number = "+6283865857106"
# The first parameter is the .session file name (absolute paths allowed)
client = TelegramClient(phone_number, api_id, api_hash)

client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone_number)
    me = client.sign_in(phone_number, input('Enter code : '))

myself = client.get_me()
print ("Welcome",myself.first_name,"\n\n")

channel_username='@Dogecoin_click_bot'
channel_entity=client.get_entity(channel_username)
i = 0
while True:
  client.send_message(entity=channel_entity,message="/visit")
  sleep(2)
  posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
  url = posts.messages[0].reply_markup.rows[0].buttons[0].url
  id = posts.messages[0].id
  print ("Memulai Menuyul....!")
  r = c.get(url, headers=ua)
  soup = BeautifulSoup(r.content,"html.parser")
  if soup.find("div",class_="g-recaptcha") is None:
     i += 1
     sleep(5)
     posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
     message = posts.messages[0].message
     sec = re.findall( r'([\d.]*\d+)', message)
     sleep(int(sec[0]))
     sleep(5)
     posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
     messageres = posts.messages[1].message
     print (messageres)
     if i == 5:
        i = 0
        client.send_message(entity=channel_entity,message="/balance")
        posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
        messageId = posts.messages[0].message
        if messageId == "/balance":
           sleep(2)
           posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
           messageId = posts.messages[0].message
           print (messageId)
        else:
           print (messageId)


  else:
     print ("Captcha Detected")
     client(GetBotCallbackAnswerRequest(
     channel_username,
     id,
     data=posts.messages[0].reply_markup.rows[0].buttons[1].data
     ))
     print ("Skip Captcha")
