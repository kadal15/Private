u="y"
while [ $u = "y" ]
do
 python ltc.py
done
